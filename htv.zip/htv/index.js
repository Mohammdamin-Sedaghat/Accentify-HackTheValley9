
// let userInput = 0;
// //element.classList.add("Board_fall");
// document.getElementById("micro").onclick = function(){
//     if (userInput == 0){
//         console.log("asshole");
//         setTimeout(function(){
//             document.getElementById("rectangleID").style.display = 'none';
        
//         const underRectangle = document.getElementById("underRectangleID");
//         underRectangle.style.visibility = 'visible';  // Make it visible
//         void underRectangle.offsetWidth;
//         underRectangle.style.left = '0';
//         underRectangle.style.top = '0';
//         underRectangle.style.borderRadius = '0px';
//         underRectangle.style.height = '100vh';  // Target full height minus header space
//         underRectangle.style.width = '100vw';  // Target full width
//         setTimeout(function() {
//             window.location.href = 'loadingScreen.html';
//         }, 100);
//         }, 500);


//     }
// }

